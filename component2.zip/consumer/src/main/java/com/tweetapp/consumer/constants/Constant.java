package com.tweetapp.consumer.constants;

public interface Constant {
    String USER_EVENTS = "user-events";
    String TWEET_EVENTS = "tweet-events";
    String COMMENT_EVENTS = "comment-events";
}

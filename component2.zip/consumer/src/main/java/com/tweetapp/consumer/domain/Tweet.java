package com.tweetapp.consumer.domain;

import lombok.*;
import org.springframework.data.annotation.Transient;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Table
public class Tweet {
    @PrimaryKey
    private UUID tweetId;
    @NotNull
    private String tweetMessage;
    @NotNull
    private String userName;
    @NotNull
    private LocalDate tweetDate;
    private Integer likes;
    private Set<UUID> commentIds = new HashSet<>();
    @Transient
    private String tweetEventType;
}

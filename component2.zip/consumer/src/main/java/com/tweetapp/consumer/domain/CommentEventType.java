package com.tweetapp.consumer.domain;

public enum CommentEventType {
  CREATE_COMMENT
}

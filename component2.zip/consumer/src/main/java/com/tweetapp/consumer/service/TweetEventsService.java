package com.tweetapp.consumer.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweetapp.consumer.domain.Tweet;
import com.tweetapp.consumer.domain.TweetEventType;
import com.tweetapp.consumer.domain.User;
import com.tweetapp.consumer.domain.UserEventType;
import com.tweetapp.consumer.repository.TweetRepository;
import com.tweetapp.consumer.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class TweetEventsService {

  @Autowired
  ObjectMapper objectMapper;

  @Autowired
  TweetRepository tweetRepository;

  public void processTweetEvent(ConsumerRecord<UUID, String> consumerRecord) throws JsonProcessingException {
    Tweet tweet = objectMapper.readValue(consumerRecord.value(), Tweet.class);
    log.info("TweetEvent : {} ", tweet);

    if (tweet.getTweetEventType() == null) {
      throw new IllegalArgumentException("Tweet Event Type is missing");
    }

    if(tweet.getTweetEventType().equalsIgnoreCase(TweetEventType.NEW.toString())) {
      createOrUpdateTweet(tweet);
    } else if(tweet.getTweetEventType().equalsIgnoreCase(TweetEventType.UPDATE_TWEET.toString())) {
      updateTweet(tweet);
    } else if(tweet.getTweetEventType().equalsIgnoreCase(TweetEventType.DELETE_TWEET.toString())) {
      deleteTweet(tweet);
    } else if(tweet.getTweetEventType().equalsIgnoreCase(TweetEventType.ADD_LIKE.toString())) {
      addLike(tweet);
    } else if(tweet.getTweetEventType().equalsIgnoreCase(TweetEventType.ADD_COMMENT.toString())) {
      addComment(tweet);
    } else {
      log.info("Invalid Tweet Event Type");
    }
  }

  private void createOrUpdateTweet(Tweet tweet) {
    tweetRepository.save(tweet);
    log.info("Successfully Persisted the Tweet Event {} ", tweet);
  }

  private void updateTweet(Tweet tweet) {
    Optional<Tweet> tweetOptional = tweetRepository.findById(tweet.getTweetId());
    if (!tweetOptional.isPresent()) {
      throw new IllegalArgumentException("No Tweet Found");
    }
    Tweet existingTweet = tweetOptional.get();
    log.info("ExistingTweet::{}", existingTweet);
    existingTweet.setTweetMessage(tweet.getTweetMessage());
    createOrUpdateTweet(existingTweet);
    log.info("Updated Tweet with Message and TweetDate is successful for the Tweet Event : {} ", existingTweet);
  }

  public void deleteTweet(Tweet tweet) {
    try {
      tweetRepository.deleteById(tweet.getTweetId());
    } catch (Exception e) {
      log.info("Not able to delete Tweet with Id::{}", tweet.getTweetId());
      log.info("Exception While Deleting::{}", e);
      throw e;
    }
    log.info("Deleted Tweet for the Tweet Event : {} ", tweet);
  }

  private void addLike(Tweet tweet) {
    Optional<Tweet> tweetOptional = tweetRepository.findById(tweet.getTweetId());
    if (!tweetOptional.isPresent()) {
      throw new IllegalArgumentException("No Tweet Found");
    }
    Tweet existingTweet = tweetOptional.get();
    log.info("ExistingTweet::{}", existingTweet);
    existingTweet.setLikes(tweet.getLikes());
    createOrUpdateTweet(existingTweet);
    log.info("Updated Tweet with likes is successful for the Tweet Event : {} ", existingTweet);
  }

  private void addComment(Tweet tweet) {
    Optional<Tweet> tweetOptional = tweetRepository.findById(tweet.getTweetId());
    if (!tweetOptional.isPresent()) {
      throw new IllegalArgumentException("No Tweet Found");
    }
    Tweet existingTweet = tweetOptional.get();
    log.info("ExistingTweet::{}", existingTweet);
    if(Objects.nonNull(existingTweet.getCommentIds())
            && !CollectionUtils.isEmpty(existingTweet.getCommentIds())) {
      existingTweet.getCommentIds().addAll(tweet.getCommentIds());
    } else {
      existingTweet.setCommentIds(tweet.getCommentIds());
    }
    createOrUpdateTweet(existingTweet);
    log.info("Updated Tweet with CommentIds is successful for the Tweet Event : {} ", existingTweet);
  }
}

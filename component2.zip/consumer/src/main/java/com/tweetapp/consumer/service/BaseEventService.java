package com.tweetapp.consumer.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.UUID;

@Component
@Slf4j
public class BaseEventService {

  @Autowired
  KafkaTemplate<UUID,String> kafkaTemplate;

  public void handleRecovery(ConsumerRecord<UUID,String> record){

    UUID key = record.key();
    String message = record.value();

    ListenableFuture<SendResult<UUID,String>> listenableFuture = kafkaTemplate.sendDefault(key, message);
    listenableFuture.addCallback(new ListenableFutureCallback<SendResult<UUID, String>>() {
      @Override
      public void onFailure(Throwable ex) {
        handleFailure(key, message, ex);
      }

      @Override
      public void onSuccess(SendResult<UUID, String> result) {
        handleSuccess(key, message, result);
      }
    });
  }

  private void handleFailure(UUID key, String value, Throwable ex) {
    log.error("Error Sending the Message and the exception is {}", ex.getMessage());
    try {
      throw ex;
    } catch (Throwable throwable) {
      log.error("Error in OnFailure: {}", throwable.getMessage());
    }
  }

  private void handleSuccess(UUID key, String value, SendResult<UUID, String> result) {
    log.info("Message Sent SuccessFully for the key : {} and the value is {} , partition is {}",
            key, value, result.getRecordMetadata().partition());
  }

}

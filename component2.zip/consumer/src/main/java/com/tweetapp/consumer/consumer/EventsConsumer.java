package com.tweetapp.consumer.consumer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.tweetapp.consumer.constants.Constant;
import com.tweetapp.consumer.service.CommentEventsService;
import com.tweetapp.consumer.service.TweetEventsService;
import com.tweetapp.consumer.service.UserEventsService;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@Slf4j
public class EventsConsumer {

  @Autowired
  private UserEventsService userEventsService;

  @Autowired
  private TweetEventsService tweetEventsService;

  @Autowired
  private CommentEventsService commentEventsService;

  @KafkaListener(topics = {Constant.USER_EVENTS})
  public void userEvent(ConsumerRecord<UUID, String> consumerRecord) throws JsonProcessingException {
    log.info("Consumer User Record : {} ", consumerRecord);
    userEventsService.processUserEvent(consumerRecord);
  }

  @KafkaListener(topics = {Constant.TWEET_EVENTS})
  public void tweetEvent(ConsumerRecord<UUID, String> consumerRecord) throws JsonProcessingException {
    log.info("Consumer Tweet Record : {} ", consumerRecord);
    tweetEventsService.processTweetEvent(consumerRecord);
  }

  @KafkaListener(topics = {Constant.COMMENT_EVENTS})
  public void commentEvent(ConsumerRecord<UUID, String> consumerRecord) throws JsonProcessingException {
    log.info("Consumer Comment Record : {} ", consumerRecord);
    commentEventsService.processCommentsEvent(consumerRecord);
  }

//    @KafkaListener(topics = {Constant.USER_EVENTS})
//    public void onMessage(ConsumerRecord<Integer,String> consumerRecord) throws JsonProcessingException {
//        log.info("ConsumerRecord : {} ", consumerRecord );
//        userEventsService.processUserEvent(consumerRecord);
//    }
}

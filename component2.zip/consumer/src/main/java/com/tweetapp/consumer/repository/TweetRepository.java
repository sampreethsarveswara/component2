package com.tweetapp.consumer.repository;

import com.tweetapp.consumer.domain.Tweet;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.UUID;

public interface TweetRepository extends CassandraRepository<Tweet, UUID> {
}

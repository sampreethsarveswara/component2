package com.tweetapp.consumer.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweetapp.consumer.domain.User;
import com.tweetapp.consumer.domain.UserEventType;
import com.tweetapp.consumer.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class UserEventsService {

  @Autowired
  ObjectMapper objectMapper;

  @Autowired
  UserRepository userRepository;

  public void processUserEvent(ConsumerRecord<UUID, String> consumerRecord) throws JsonProcessingException {
    User user = objectMapper.readValue(consumerRecord.value(), User.class);
    log.info("UserEvent : {} ", user);

    if (user.getUserEventType() == null) {
      throw new IllegalArgumentException("User Event Id is missing");
    }

    if(user.getUserEventType().equalsIgnoreCase(UserEventType.NEW.toString())) {
      save(user);
    } else if(user.getUserEventType().equalsIgnoreCase(UserEventType.UPDATE_PASSWORD.toString())) {
      updatePassword(user);
    } else if(user.getUserEventType().equalsIgnoreCase(UserEventType.ADD_TWEET.toString())) {
      addTweet(user);
    } else {
      log.info("Invalid User Event Type");
    }
  }

  private void save(User user) {
    userRepository.save(user);
    log.info("Successfully Persisted the User Event {} ", user);
  }

  private void updatePassword(User user) {
    Optional<User> userOptional = userRepository.findById(user.getUserId());
    if (!userOptional.isPresent()) {
      throw new IllegalArgumentException("No User Found");
    }
    User existingUser = userOptional.get();
    log.info("ExistingUser::{}", existingUser);
    existingUser.setPassword(user.getPassword());
    save(existingUser);
    log.info("Updated Password is successful for the User Event : {} ", existingUser);
  }

  private void addTweet(User user) {
    Optional<User> userOptional = userRepository.findById(user.getUserId());
    if (!userOptional.isPresent()) {
      throw new IllegalArgumentException("No User Found");
    }
    User existingUser = userOptional.get();
    log.info("ExistingUser::{}", existingUser);
    if(Objects.nonNull(existingUser.getTweetIds())
            && !CollectionUtils.isEmpty(existingUser.getTweetIds())) {
      existingUser.getTweetIds().addAll(user.getTweetIds());
    } else {
      existingUser.setTweetIds(user.getTweetIds());
    }
    save(existingUser);
    log.info("Updated User with TweetIds is successful for the User Event : {} ", existingUser);
  }
}

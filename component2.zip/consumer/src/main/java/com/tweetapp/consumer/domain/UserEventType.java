package com.tweetapp.consumer.domain;

public enum UserEventType {
    NEW,
    UPDATE_PASSWORD,
    ADD_TWEET
}

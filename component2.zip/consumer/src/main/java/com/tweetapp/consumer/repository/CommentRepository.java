package com.tweetapp.consumer.repository;

import com.tweetapp.consumer.domain.Comment;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.UUID;

public interface CommentRepository extends CassandraRepository<Comment, UUID> {
}

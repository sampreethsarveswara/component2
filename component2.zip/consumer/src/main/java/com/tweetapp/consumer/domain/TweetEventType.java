package com.tweetapp.consumer.domain;

public enum TweetEventType {
  NEW,
  UPDATE_TWEET,
  DELETE_TWEET,
  ADD_LIKE,
  ADD_COMMENT
}

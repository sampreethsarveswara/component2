package com.tweetapp.consumer.repository;

import com.tweetapp.consumer.domain.User;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.UUID;

public interface UserRepository extends CassandraRepository<User, UUID> {

}

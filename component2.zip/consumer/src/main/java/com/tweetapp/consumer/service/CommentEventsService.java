package com.tweetapp.consumer.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweetapp.consumer.domain.Comment;
import com.tweetapp.consumer.domain.CommentEventType;
import com.tweetapp.consumer.domain.UserEventType;
import com.tweetapp.consumer.repository.CommentRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class CommentEventsService {

  @Autowired
  ObjectMapper objectMapper;

  @Autowired
  CommentRepository commentRepository;

  public void processCommentsEvent(ConsumerRecord<UUID, String> consumerRecord) throws JsonProcessingException {
    Comment comment = objectMapper.readValue(consumerRecord.value(), Comment.class);
    log.info("CommentEvent : {} ", comment);

    if (comment.getCommentEventType() == null) {
      throw new IllegalArgumentException("Comment Event Type is missing");
    }

    if(comment.getCommentEventType().equalsIgnoreCase(CommentEventType.CREATE_COMMENT.toString())) {
      save(comment);
    } else {
      log.info("Invalid User Event Type");
    }
  }

  private void save(Comment comment) {
    commentRepository.save(comment);
    log.info("Successfully Persisted the Comment Event {} ", comment);
  }
}

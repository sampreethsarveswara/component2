package com.tweetapp.producer.controller;

import com.datastax.driver.core.utils.UUIDs;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.tweetapp.producer.domain.Tweet;
import com.tweetapp.producer.domain.User;
import com.tweetapp.producer.domain.UserEventType;
import com.tweetapp.producer.producer.UserEventProducer;
import com.tweetapp.producer.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutionException;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@Slf4j
@RequestMapping("/api")
public class UserEventsController {

  @Autowired
  UserRepository userRepository;

  @Autowired
  UserEventProducer userEventProducer;

  @PostMapping("/user-register")
  public ResponseEntity<?> userRegistration(@RequestBody @Valid User user)  {
    try {
      User checkExistingUserName = userRepository.findByUserName(user.getUserName());
      if(Objects.nonNull(checkExistingUserName)) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("UserName already Exists");
      }
      User checkExistingUserEmail = userRepository.findByUserEmail(user.getEmail());
      if(Objects.nonNull(checkExistingUserEmail)) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email already Exists");
      }
      user.setUserEventType(UserEventType.NEW.toString());
      user.setUserId(UUIDs.timeBased());
      userEventProducer.sendUserEvent(user);
      return ResponseEntity.status(HttpStatus.CREATED).body(user);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @PutMapping("/update-password")
  public ResponseEntity<?> updateUserPassword(@RequestBody User user) throws JsonProcessingException {
    if(user.getUserId()==null){
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please pass the userId");
    }
    user.setUserEventType(UserEventType.UPDATE_PASSWORD.toString());
    userEventProducer.sendUserEvent(user);
    return ResponseEntity.status(HttpStatus.OK).body(user);
  }

  @GetMapping("/users/all")
  public ResponseEntity<List<User>> getAllUsers() {
    try {
      List<User> users = new ArrayList<User>();
      userRepository.findAll().forEach(users::add);
      if (users.isEmpty()) {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
      }
      return new ResponseEntity<>(users, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @GetMapping("/users/search/{username}")
  public ResponseEntity<List<User>> getUserSearch(@PathVariable("username") String username) {
    try {
      List<User> users = new ArrayList<User>();
      userRepository.findByUserNameContaining(username).forEach(users::add);
      if (users.isEmpty()) {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
      }
      return new ResponseEntity<>(users, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @GetMapping("/users/login")
  public ResponseEntity<?> userLogin(@RequestBody User user) {
    try {
      User checkExistingUser = userRepository.findByUserName(user.getUserName());
      if(Objects.isNull(checkExistingUser)) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No UserName Found");
      }
      String password = checkExistingUser.getPassword();
      if(!password.equalsIgnoreCase(user.getPassword())) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Password Wrong");
      }
      return new ResponseEntity<>(checkExistingUser, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
}

package com.tweetapp.producer.domain;

public enum UserEventType {
    NEW,
    UPDATE_PASSWORD,
    ADD_TWEET,
    DELETE_TWEET
}

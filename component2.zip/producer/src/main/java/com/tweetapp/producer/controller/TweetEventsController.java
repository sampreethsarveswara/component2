package com.tweetapp.producer.controller;

import com.datastax.driver.core.utils.UUIDs;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.tweetapp.producer.domain.*;
import com.tweetapp.producer.helper.Helper;
import com.tweetapp.producer.producer.TweetEventProducer;
import com.tweetapp.producer.producer.UserEventProducer;
import com.tweetapp.producer.repository.CommentRepository;
import com.tweetapp.producer.repository.TweetRepository;
import com.tweetapp.producer.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@Slf4j
@RequestMapping("/api")
public class TweetEventsController {

  @Autowired
  TweetRepository tweetRepository;

  @Autowired
  CommentRepository commentRepository;

  @Autowired
  TweetEventProducer tweetEventProducer;

  @Autowired
  UserEventProducer userEventProducer;

  @Autowired
  Helper helper;

  @PostMapping("/add-tweet")
  public ResponseEntity<?> createTweet(@RequestBody Tweet tweet) {
    if (tweet.getUserName() == null) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please pass the userName");
    }
    try {
      tweet.setTweetEventType(TweetEventType.NEW.toString());
      tweet.setTweetId(UUIDs.timeBased());
      tweet.setTweetDate(LocalDate.now());
      tweetEventProducer.sendTweetEvent(tweet);
      updateUserEventAddTweet(tweet.getTweetId(), tweet.getUserName());
      return ResponseEntity.status(HttpStatus.CREATED).body(tweet);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  private void updateUserEventAddTweet(UUID tweetId, String userName) {
    User user = helper.getUserByUserName(userName);
    user.setUserEventType(UserEventType.ADD_TWEET.toString());
    if (Objects.nonNull(user.getTweetIds())) {
      user.getTweetIds().add(tweetId);
    } else {
      user.setTweetIds(new HashSet<>(Arrays.asList(tweetId)));
    }
    try {
      userEventProducer.sendUserEvent(user);
    } catch (Exception e) {
      log.info("Not able to Update TweetIds for userName::{}", userName);
    }
  }

  @PutMapping("/update-tweet")
  public ResponseEntity<?> updateTweet(@RequestBody Tweet tweet) throws JsonProcessingException, ExecutionException, InterruptedException {
    if (tweet.getTweetId() == null) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please pass the tweetId");
    }
    tweet.setTweetEventType(TweetEventType.UPDATE_TWEET.toString());
    tweetEventProducer.sendTweetEvent(tweet);
    return ResponseEntity.status(HttpStatus.OK).body(tweet);
  }

  @PutMapping("/add-like")
  public ResponseEntity<?> likeTweet(@RequestBody Tweet tweet) throws JsonProcessingException, ExecutionException, InterruptedException {
    if (tweet.getTweetId() == null) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please pass the tweetId");
    }
    tweet.setTweetEventType(TweetEventType.ADD_LIKE.toString());
    tweetEventProducer.sendTweetEvent(tweet);
    return ResponseEntity.status(HttpStatus.OK).body(tweet);
  }

  @DeleteMapping("/delete-tweet/{id}")
  public ResponseEntity<HttpStatus> deleteTutorial(@PathVariable("id") UUID tweetId) {
    try {
      Tweet tweet = new Tweet();
      tweet.setTweetId(tweetId);
      tweet.setTweetEventType(TweetEventType.DELETE_TWEET.toString());
      tweetEventProducer.sendTweetEvent(tweet);
      updateUserEventDeleteTweet(tweet.getTweetId(), tweet.getUserName());
      return new ResponseEntity<>(HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  private void updateUserEventDeleteTweet(UUID tweetId, String userName) {
    User user = helper.getUserByUserName(userName);
    user.setUserEventType(UserEventType.DELETE_TWEET.toString());
    user.getTweetIds().remove(tweetId);
    try {
      userEventProducer.sendUserEvent(user);
    } catch (Exception e) {
      log.info("Not able to Update TweetIds for userName::{}", userName);
    }
  }

  @GetMapping("/tweets/all")
  public ResponseEntity<List<Tweet>> getAllTweets() {
    try {
      List<Tweet> tweets = new ArrayList<Tweet>();
      tweetRepository.findAll().forEach(tweets::add);
      if (tweets.isEmpty()) {
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
      }
      tweets.forEach(tweet -> fillCommentsForTweets(tweet));
      return new ResponseEntity<>(tweets, HttpStatus.OK);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @GetMapping("/tweets/{username}")
  public ResponseEntity<?> getTweetsByUserName(@PathVariable("username") String username) {
    List<Tweet> tweetsData = tweetRepository.findByUserName(username);
    if (!CollectionUtils.isEmpty(tweetsData)) {
      tweetsData.forEach(tweet -> fillCommentsForTweets(tweet));
      return new ResponseEntity<>(tweetsData, HttpStatus.OK);
    } else {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
  }

  private void fillCommentsForTweets(Tweet tweet) {
    if(Objects.nonNull(tweet.getCommentIds())
            && !CollectionUtils.isEmpty(tweet.getCommentIds())) {
      List<Comment> comments = new ArrayList<>();
      tweet.getCommentIds()
              .stream()
              .map(commentId -> commentRepository.findById(commentId))
              .forEach(comment -> {
                if(comment.isPresent()) {
                  comments.add(comment.get());
                }
              });
      tweet.setComments(comments);
    }
  }
}

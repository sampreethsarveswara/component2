package com.tweetapp.producer.producer;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Component
@Slf4j
public class BaseEventProducer {

  protected ProducerRecord<UUID, String> buildProducerRecord(
          UUID key, String value, String topic) {
    List<Header> recordHeaders = Arrays.asList(new RecordHeader("event-source", "scanner".getBytes()));
    return new ProducerRecord<>(topic, null, key, value, recordHeaders);
  }

  protected void handleFailure(UUID key, String value, Throwable ex) {
    log.error("Error Sending the Message and the exception is {}", ex.getMessage());
    try {
      throw ex;
    } catch (Throwable throwable) {
      log.error("Error in OnFailure: {}", throwable.getMessage());
    }
  }

  protected void handleSuccess(UUID key, String value, SendResult<UUID, String> result) {
    log.info("Message Sent SuccessFully for the key : {} and the value is {} , partition is {}",
            key, value, result.getRecordMetadata().partition());
  }
}

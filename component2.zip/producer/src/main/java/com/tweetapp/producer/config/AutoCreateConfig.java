package com.tweetapp.producer.config;

import com.tweetapp.producer.constants.Constant;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;

@Configuration
public class AutoCreateConfig {

    @Bean
    public NewTopic userEvents(){
        return TopicBuilder.name(Constant.USER_EVENTS)
                .build();
    }
    @Bean
    public NewTopic tweetEvents(){
        return TopicBuilder.name(Constant.TWEET_EVENTS)
                .build();
    }
    @Bean
    public NewTopic commentEvents(){
        return TopicBuilder.name(Constant.COMMENT_EVENTS)
                .build();
    }
}

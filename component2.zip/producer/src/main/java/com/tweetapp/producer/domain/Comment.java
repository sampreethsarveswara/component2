package com.tweetapp.producer.domain;

import lombok.*;
import org.springframework.data.annotation.Transient;
import org.springframework.data.cassandra.core.mapping.PrimaryKey;
import org.springframework.data.cassandra.core.mapping.Table;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
@Table
public class Comment {
    @PrimaryKey
    private UUID commentId;
    @NotNull
    private String commentMessage;
    @NotNull
    private UUID tweetId;
    @NotNull
    private LocalDate commentDate;
    @NotNull
    private String userName;
    @Transient
    private String commentEventType;
}

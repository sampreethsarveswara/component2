package com.tweetapp.producer.domain;

public enum TweetEventType {
  NEW,
  UPDATE_TWEET,
  DELETE_TWEET,
  ADD_LIKE,
  ADD_COMMENT
}

package com.tweetapp.producer.jwt;

import com.tweetapp.producer.domain.User;
import com.tweetapp.producer.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class JwtInMemoryUserDetailsService implements UserDetailsService {

    @Autowired
    UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
       User user = userRepository.findByUserName(username);

        if (Objects.isNull(user)) {
            throw new UsernameNotFoundException(String.format("USER_NOT_FOUND '%s'.", username));
        }
      BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
      String password = user.getPassword();
      String endodedPassword = bCryptPasswordEncoder.encode(password);

        JwtUserDetails jwtUserDetails = new JwtUserDetails(user.getUserId(), user.getUserName(),endodedPassword);

        return jwtUserDetails;
    }

}
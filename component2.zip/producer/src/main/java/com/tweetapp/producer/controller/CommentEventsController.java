package com.tweetapp.producer.controller;

import com.datastax.driver.core.utils.UUIDs;
import com.tweetapp.producer.domain.*;
import com.tweetapp.producer.helper.Helper;
import com.tweetapp.producer.producer.CommentEventProducer;
import com.tweetapp.producer.producer.TweetEventProducer;
import com.tweetapp.producer.producer.UserEventProducer;
import com.tweetapp.producer.repository.CommentRepository;
import com.tweetapp.producer.repository.TweetRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;
import java.util.UUID;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@Slf4j
@RequestMapping("/api/tweets")
public class CommentEventsController {

  @Autowired
  CommentRepository commentRepository;

  @Autowired
  CommentEventProducer commentEventProducer;

  @Autowired
  TweetEventProducer tweetEventProducer;

  @Autowired
  Helper helper;

  @PostMapping("/add-comment")
  public ResponseEntity<?> createTweet(@RequestBody Comment comment) {
    if (comment.getTweetId() == null || comment.getUserName() == null) {
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Please pass the tweetId and userName");
    }
    try {
      comment.setCommentEventType(CommentEventType.CREATE_COMMENT.toString());
      comment.setCommentId(UUIDs.timeBased());
      comment.setCommentDate(LocalDate.now());
      commentEventProducer.sendCommentsEvent(comment);
      updateTweetEventAddComment(comment.getCommentId(), comment.getTweetId());
      return ResponseEntity.status(HttpStatus.CREATED).body(comment);
    } catch (Exception e) {
      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  private void updateTweetEventAddComment(UUID commentId, UUID tweetId) {
    Tweet tweet = helper.getTweetById(tweetId);
    tweet.setTweetEventType(TweetEventType.ADD_COMMENT.toString());
    if (Objects.nonNull(tweet.getCommentIds())) {
      tweet.getCommentIds().add(commentId);
    } else {
      tweet.setCommentIds(new HashSet<>(Arrays.asList(commentId)));
    }
    try {
      tweetEventProducer.sendTweetEvent(tweet);
    } catch (Exception e) {
      log.info("Not able to Update CommentIds for tweet::{}", tweet);
    }
  }
}

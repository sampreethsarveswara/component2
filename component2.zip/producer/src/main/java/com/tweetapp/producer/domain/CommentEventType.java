package com.tweetapp.producer.domain;

public enum CommentEventType {
  CREATE_COMMENT
}

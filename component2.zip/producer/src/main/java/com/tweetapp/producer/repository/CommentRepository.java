package com.tweetapp.producer.repository;

import com.tweetapp.producer.domain.Comment;
import org.springframework.data.cassandra.repository.CassandraRepository;

import java.util.UUID;

public interface CommentRepository extends CassandraRepository<Comment, UUID> {
}

package com.tweetapp.producer.producer;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweetapp.producer.constants.Constant;
import com.tweetapp.producer.domain.Comment;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Component
@Slf4j
public class CommentEventProducer extends BaseEventProducer{

  @Autowired
  KafkaTemplate<UUID,String> kafkaTemplate;

  String topic = Constant.COMMENT_EVENTS;

  @Autowired
  ObjectMapper objectMapper;


  public ListenableFuture<SendResult<UUID, String>> sendCommentsEvent(
          Comment comment) throws JsonProcessingException {

    UUID key = comment.getCommentId();
    String value = objectMapper.writeValueAsString(comment);

    ProducerRecord<UUID, String> producerRecord = buildProducerRecord(key, value, topic);

    ListenableFuture<SendResult<UUID, String>> listenableFuture = kafkaTemplate.send(producerRecord);

    listenableFuture.addCallback(new ListenableFutureCallback<SendResult<UUID, String>>() {
      @Override
      public void onFailure(Throwable ex) {
        handleFailure(key, value, ex);
      }

      @Override
      public void onSuccess(SendResult<UUID, String> result) {
        handleSuccess(key, value, result);
      }
    });
    return listenableFuture;
  }
}

package com.tweetapp.producer.repository;

import com.tweetapp.producer.domain.User;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;
import java.util.UUID;

public interface UserRepository extends CassandraRepository<User, UUID> {

  @Query("SELECT * from user WHERE username=?0")
  User findByUserName(String userName);

  @Query("SELECT * from user WHERE email=?0")
  User findByUserEmail(String email);

  List<User> findByUserNameContaining(String userName);
}

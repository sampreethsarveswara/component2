package com.tweetapp.producer.repository;

import com.tweetapp.producer.domain.Tweet;
import com.tweetapp.producer.domain.User;
import org.springframework.data.cassandra.repository.AllowFiltering;
import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;

import java.util.List;
import java.util.UUID;

public interface TweetRepository extends CassandraRepository<Tweet, UUID> {

  @AllowFiltering
  List<Tweet> findByUserName(String userName);
}

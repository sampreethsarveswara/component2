package com.tweetapp.producer.helper;

import com.tweetapp.producer.domain.Tweet;
import com.tweetapp.producer.domain.User;
import com.tweetapp.producer.repository.CommentRepository;
import com.tweetapp.producer.repository.TweetRepository;
import com.tweetapp.producer.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.UUID;

@Component
@Slf4j
public class Helper {
  @Autowired
  TweetRepository tweetRepository;
  @Autowired
  UserRepository userRepository;
  @Autowired
  CommentRepository commentRepository;

  public User getUserByUserName(String userName) {
    User user;
    try {
      user = userRepository.findByUserName(userName);
    } catch (Exception e) {
      log.info("Not able to retrieve by userName");
      throw e;
    }
    return user;
  }

  public Tweet getTweetById(UUID tweetId) {
    try {
      Optional<Tweet> optionalTweet = tweetRepository.findById(tweetId);
      return optionalTweet.get();
    } catch (Exception e) {
      log.info("Not able to retrieve by userName");
      throw e;
    }
  }
}

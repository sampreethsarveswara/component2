import { Component } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  isLogin: any;
  constructor(private router: ActivatedRoute) {
    console.log(this.router.snapshot);
    //this.isLogin = this.router.url === '/';
  }
  title = 'twitter-clone';
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
}

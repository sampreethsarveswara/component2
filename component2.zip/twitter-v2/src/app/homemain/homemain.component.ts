import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homemain',
  templateUrl: './homemain.component.html',
  styleUrls: ['./homemain.component.css']
})
export class HomemainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
